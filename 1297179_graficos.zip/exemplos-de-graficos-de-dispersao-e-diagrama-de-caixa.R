###################################################################
# ler uma tabela com cabe�alho
# [, 1]	mpg	Miles/(US) gallon
# [, 2]	cyl	Number of cylinders
# [, 3]	disp	Displacement (cu.in.)
# [, 4]	hp	Gross horsepower
# [, 5]	drat	Rear axle ratio
# [, 6]	wt	Weight (1000 lbs)
# [, 7]	qsec	1/4 mile time
# [, 8]	vs	V/S
# [, 9]	am	Transmission (0 = automatic, 1 = manual)
# [,10]	gear	Number of forward gears
# [,11]	carb	Number of carburetors
###################################################################
# ler de um arquivo uma tabela com cabe�alho e com separador ":"
Carros = read.table("carros-1.txt",header=TRUE,sep=":")

# abre um dispositivo gr�fico (scatter plot)
#png(file = "exemplo-de-grafico-de-dispersao.jpg")

# gerar um gr�fico de dispers�o 
plot(
  # referencia os atributos wt e mpg
  Carros$wt,Carros$mpg, 
  # t�tulo do gr�fico
  main="Peso x Milhas por Gal�o de Gasolina",
  xlab="Peso (1000 lbs)", # t�tulo de x
  ylab="Milhas por gal�o", # t�tulo de y
  # define os limites dos eixos
#     xlim=c(2.5,5), ylim=c(15,30)
)
# fecha um dispositivo gr�fico
#dev.off()

###################################################################
# gerar uma matriz de gr�ficos de dispers�o
###################################################################
# ler de um arquivo uma tabela com cabe�alho e com separador ":"
Carros = read.table("carros-1.txt",header=TRUE,sep=":")

# abre um dispositivo gr�fico
#png(file = "exemplo-de-grafico-de-matriz-de-dispersao.jpg")

# gerar uma matriz de gr�ficos de dispers�o
pairs(
  # atributos que s�o utilizados (referenciados)
  ~wt+mpg+disp+cyl,
  data = Carros, # os dados usados
  # t�tulo do gr�fico
  main = "Matriz de Gr�ficos de Dispers�o",
  # t�tulos dos gr�ficos de dispers�o
  labels = c("Peso","Milhas/Gal�o","Nro.Cilindros","Cilindrada")
)
# fecha um dispositivo gr�fico
#dev.off()

###################################################################
# gerar um diagrama de bloco (boxplot)
###################################################################
# ler de um arquivo uma tabela com cabe�alho e com separador ":"
Carros = read.table("carros-1.txt",header=TRUE,sep=":")

# abre um dispositivo gr�fico
#png(file = "exemplo-de-grafico-de-diagrama-de-caixa.jpg")

# gera um diagrama de caixa
boxplot(mpg ~ cyl, # atributos
  data=Carros, # dados
  # t�tulo do gr�fico
  main="Milhas por Gal�o x Cilindradas",
  # nome do eixo x
  xlab="N�mero de cilindros",
  # nome do eixo y  
  ylab="Milhas por gal�o"
)
# fecha um dispositivo gr�fico
#dev.off()
