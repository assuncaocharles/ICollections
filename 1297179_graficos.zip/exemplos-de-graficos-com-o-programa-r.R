#####################
# Gr�fico de barras
#####################
#A = c(1,2,3,4,5,6,7,8,9)
B = c(10,25,30,54,35,60,20,30,40)
# abre um dispositivo gr�fico
#png(file = "exemplo-de-grafico-de-barras-na-vertical.jpg")
# gera gr�fico de barras na vertical
barplot(B, # conjunto de dados
  main="Produ��o Anual de Soja", #titulo
  ylab="Tonelada", # nome do eixo y
  xlab="Fazenda",  # nome do eixo x
  horiz="false",   # posi��o das barras
  # nomes das barras  
  names.arg=c(1, 2, 3, 4, 5, 6, 7, 8, 9),
  # cores das barras
  col = c("gray","yellow","lightblue", "mistyrose","lightcyan", "lavender", "cyan", "magenta", "brown")
)
# fecha o dispositivo gr�fico
#dev.off()

# abre um dispositivo gr�fico
#png(file = "exemplo-de-grafico-de-barras-na-horizontal.jpg")
# gera gr�fico de barras na horizontal
barplot(B, # conjunto de dados
  main="Produ��o Anual de Soja", #titulo
  xlab="Tonelada", # nome do eixo x
  ylab="Fazenda",  # nome do eixo y
  horiz="true",    # posi��o das barras
  # nomes das barras
  names.arg=c("A", "B", "C", "D", "E", "F", "G", "H", "I"), 
  # cores das barras
  col = c("gray","yellow","lightblue", "mistyrose","lightcyan", "lavender", "cyan", "magenta", "brown")
)
# fecha o dispositivo gr�fico
#dev.off()

###################
# Histogramas
###################
C = c(5,3,2,4,5,3,4,5,6,3,4,5,6,7,1,0,5,6,6,0,8,9)
# abre um dispositivo gr�fico
#png(file = "exemplo-de-histograma-frequencia-absoluta.jpg")
# histograma utilizando a densidade
hist(C, # conjunto de dados
  main="Notas do 1o. Bimestre", # titulo
  xlab="Nota", # nome do eixo x
  ylab="Densidade", # nome do eixo y
  # cores das barras
  col = c("mistyrose","lavender"),
  # n�o usa a frequ�ncia absoluta (usa densidade)
  freq=FALSE, 
)
# fecha o dispositivo gr�fico
#dev.off()

# abre um dispositivo gr�fico
#png(file = "exemplo-de-histograma-densidade-de-probabilidade.jpg")
# histograma utilizando a frequ�ncia absoluta
hist(C, # conjunto de dados
  main="Notas do 1o. Bimestre", # titulo
  xlab="Nota", # nome do eixo x				
  ylab="Frequ�ncia absoluta", # nome do eixo y
  # cores das barras
  col= c("lightblue","lightgray"), 
  # usa a frequ�ncia absoluta
  freq=TRUE 
)
# fecha o dispositivo gr�fico
#dev.off()

################################
# porcentagem de observa��es
################################
# cont�m as cinco faixas do histograma
N = c(0,0,0,0,0)
for (i in 1:length(C)) {
  if (C[i] <= 2)
    N[1] = n[1] + 1
  else if (C[i] <= 4)
    N[2] = n[2] + 1
  else if (C[i] <= 6)
    N[3] = n[3] + 1
  else if (C[i] <= 8)
    N[4] = n[4] + 1
  else if (C[i] <= 10)
    N[5] = n[5] + 1
}
print(n) # mostrar N
# mostrar N em porcentagem
print(N/length(C)*100)
# mostrar a soma de N
print(sum(N/length(C)*100))
# mostra valores arredondados 
print(round(N/length(C)*100))
# mostra a soma de N arredondado
print(sum(round(N/length(C)*100)))

######################################
# Gr�fico de pol�gonos de frequ�ncia
######################################
X = c(  1,  2,  3, 4, 5, 6, 7)
Y = c(120,180,145,140,130,20,10)

plot(X,Y,main="Varia��o Espont�nea",col="blue",
names.arg=c("A", "B", "C", "D", "E", "F", "G")
)
lines(X,Y,col="red")

###################
# Ogiva
###################
X = c( 5,30,40,45,50,79,82, 90)
Y = c(10,20,30,40,50,65,70,100)

plot(X,Y,
     main="Atributo Idade",
     xlab="Idade",
     ylab="Frequ�ncia absoluta",
     col="blue",
)

lines(X,Y,col="red")

###################
# Gr�fico de Pareto
###################
C = c(5,7,9,2,1)

barplot(sort(C,decreasing=TRUE),
  main="Produ��o de Feno em Dias �teis", #titulo
  ylab="Tonelada",
  xlab="Dia",
  horiz="false",
  names.arg=c("Quarta","Ter�a","Segunda","Quinta","Sexta"),
  col = c("lightblue","mistyrose","lightcyan","lavender","cyan")
)

#######################
# Gr�fico de setores
#######################
A = c(21,62,10,53) # conjunto de dados
# abre um dispositivo gr�fico
#png(file = "exemplo-de-grafico-de-setores.jpg")
pie(A,
    main="Processos Criminais", # t�tulo do gr�fico
    # r�tulos dos setores 
    labels=c("Curitiba","S�o Paulo","Porto Alegre","Florian�polis"),
#    col=rainbow(A) # outras possibilidade de cores
)
# fecha o dispositivo gr�fico
#dev.off()

###################################
# Gr�fico de setores com legenda
###################################
A = c(21,62,10,53) # conjunto de dados
# abre um dispositivo gr�fico
#png(file = "exemplo-de-grafico-de-setores-com-legenda.jpg")
# gera um gr�fico de setores
pie(A, # conjunto dos dados
    main="Processos Criminais", # t�tulo do gr�fico
    labels=round(100*A/sum(A),1), # percentagens
    col=rainbow(length(A)) # modelos de cores
)
# legenda no canto superior do gr�fico
legend("topright", # posi��o da legenda
  # conjunto com os nome dos setores
  c("Curitiba","S�o Paulo","Porto Alegre","Florian�polis"),
  cex = 0.85, # raz�o do tamanho do caractere 
  fill = rainbow(length(A)) # preencher legenda
)
# fecha o dispositivo gr�fico
#dev.off()
